:root {
  --ink: #0b0b0f;
  --muted: #2a4a8a;
  --bg: #f5f7f6;
  --card: #ffffff;
  --line: #dde4e3;
  --brand: #0f5257;
  --brand-dark: #0a3c40;
  --accent: #e8a33d;
  --danger: #b3382c;
  --ok: #2f7d4f;
  --font-blue: #1456d6;
  --font-blue-dark: #0a2f7a;
}
* { box-sizing: border-box; }
body { margin: 0; font-family: "Segoe UI", Roboto, Arial, sans-serif; color: var(--ink); background: var(--bg); line-height: 1.5; }
a { color: var(--font-blue); }
a:hover { color: var(--font-blue-dark); }
h1, h2, h3 { color: var(--font-blue-dark); }
.container { max-width: 960px; margin: 0 auto; padding: 24px 16px 48px; min-height: 70vh; }
 
.topbar { background: var(--brand); display: flex; flex-wrap: wrap; align-items: center; justify-content: space-between; padding: 12px 20px; }
.brand { color: #fff; font-size: 1.25rem; font-weight: 700; text-decoration: none; }
.topbar nav a { color: #dcefee; text-decoration: none; margin-left: 16px; font-size: .95rem; }
.topbar nav a:hover { color: #fff; text-decoration: underline; }
 
.hero { padding: 40px 0 24px; }
.hero h1 { font-size: 2.4rem; margin: 0 0 8px; }
.hero p { color: var(--muted); max-width: 560px; margin-bottom: 20px; }
 
.btn { display: inline-block; background: var(--brand); color: #fff; border: 0; padding: 10px 18px; border-radius: 6px; text-decoration: none; cursor: pointer; font-size: .95rem; }
.btn:hover { background: var(--brand-dark); }
.btn.ghost { background: transparent; color: var(--font-blue); border: 1px solid var(--brand); }
.btn.ghost:hover { background: #e6f0ef; }
.btn.danger { background: var(--danger); }
.btn.small { padding: 6px 12px; font-size: .85rem; }
 
.grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 16px; margin: 16px 0; }
.grid.stats { grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); }
.card { background: var(--card); border: 1px solid var(--line); border-radius: 8px; padding: 16px 18px; margin-bottom: 14px; }
.grid .card { margin-bottom: 0; }
.card h3 { margin: 0 0 4px; }
.stats .card h3 { font-size: 2rem; color: var(--font-blue); }
.row { display: flex; justify-content: space-between; align-items: flex-start; gap: 16px; }
.muted { color: var(--muted); }
 
.form-box { max-width: 420px; margin: 20px auto; background: var(--card); border: 1px solid var(--line); border-radius: 8px; padding: 24px; }
.form-box.wide { max-width: 680px; }
label { display: block; margin-bottom: 14px; font-weight: 600; font-size: .92rem; }
input, select, textarea { display: block; width: 100%; margin-top: 4px; padding: 9px 10px; border: 1px solid #b9c5c3; border-radius: 6px; font: inherit; color: var(--ink); background: #fff; }
input:focus, select:focus, textarea:focus, .btn:focus-visible { outline: 3px solid #f4d9a3; border-color: var(--accent); }
input.invalid, select.invalid, textarea.invalid { border-color: var(--danger); }
.field-error { color: var(--danger); font-size: .82rem; font-weight: 400; }
 
.alert { padding: 10px 14px; border-radius: 6px; margin-bottom: 14px; border: 1px solid; }
.alert.success { background: #e6f4ec; border-color: #b6dcc4; color: #1f5a37; }
.alert.error { background: #fbeceb; border-color: #efc3bf; color: #8a2a20; }
.alert.info { background: #fdf3df; border-color: #f0d9a4; color: var(--font-blue-dark); }
 
.search-bar { display: flex; flex-wrap: wrap; gap: 10px; margin: 12px 0 20px; }
.search-bar input, .search-bar select { margin-top: 0; flex: 1 1 200px; width: auto; }
 
.tag { display: inline-block; background: #e3eeed; color: var(--font-blue-dark); border-radius: 12px; padding: 2px 10px; font-size: .8rem; margin: 2px 4px 2px 0; }
 
.badge { display: inline-block; padding: 3px 12px; border-radius: 12px; font-size: .8rem; font-weight: 600; white-space: nowrap; background: #e9edec; color: var(--ink); }
.s-applied { background: #e3eeed; color: var(--font-blue-dark); }
.s-under-review { background: #fdf0d2; color: #7a5410; }
.s-shortlisted { background: #dcecf8; color: var(--font-blue); }
.s-interview { background: #e8e0f5; color: #503280; }
.s-selected { background: #dcf1e3; color: #1f6a3f; }
.s-rejected { background: #f8dedb; color: #8a2a20; }
 
.tracker { list-style: none; display: flex; padding: 0; margin: 14px 0 0; gap: 6px; }
.tracker li { flex: 1; text-align: center; font-size: .8rem; padding: 8px 4px; background: #eef2f1; color: var(--ink); border-radius: 4px; }
.tracker li.done { background: var(--brand); color: #fff; }
 
.actions { display: flex; flex-wrap: wrap; gap: 14px; margin-top: 10px; padding-top: 12px; border-top: 1px solid var(--line); }
.actions form { display: flex; gap: 8px; align-items: center; }
.actions select { margin-top: 0; width: auto; }
 
.table-wrap { overflow-x: auto; }
table { width: 100%; border-collapse: collapse; background: var(--card); border: 1px solid var(--line); }
th, td { text-align: left; padding: 10px 12px; border-bottom: 1px solid var(--line); }
th { background: #eef2f1; color: var(--font-blue-dark); font-size: .88rem; }
 
.footer { text-align: center; padding: 16px; color: var(--muted); font-size: .85rem; border-top: 1px solid var(--line); }
 
@media (max-width: 600px) {
  .topbar nav { margin-top: 8px; }
  .topbar nav a { margin: 0 12px 0 0; }
  .row { flex-direction: column; }
  .tracker { flex-direction: column; }
  .hero h1 { font-size: 1.8rem; }
}
body {
    margin: 0;
    min-height: 100vh;
    background-image: url('../images/int.jpg');
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    background-attachment: fixed;
    font-family: Arial, sans-serif;
}
.login-container,
.register-container {
    background: rgba(255, 255, 255, 0.92);
    padding: 30px;
    border-radius: 12px;
    max-width: 400px;
    margin: 80px auto;
}


<?php
if (session_status() === PHP_SESSION_NONE) session_start();

const STATUSES = ['Applied', 'Under Review', 'Shortlisted', 'Interview', 'Selected', 'Rejected'];

function e($v): string {
    return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): void {
    header('Location: ' . BASE_URL . $path);
    exit;
}

function is_logged_in(): bool {
    return !empty($_SESSION['user_id']);
}

function dashboard_path(): string {
    return ($_SESSION['role'] ?? '') === 'company'
        ? '/company/dashboard.php'
        : '/student/dashboard.php';
}

// Call at the top of protected pages: require_login('student') / ('company')
function require_login(string $role): void {
    if (!is_logged_in()) {
        flash('error', 'Please login first.');
        redirect('/login.php');
    }
    if ($_SESSION['role'] !== $role) redirect(dashboard_path());
}

// students.id / companies.id for the logged-in user
function student_id(PDO $pdo): int {
    $s = $pdo->prepare('SELECT id FROM students WHERE user_id = ?');
    $s->execute([$_SESSION['user_id']]);
    return (int)$s->fetchColumn();
}

function company_id(PDO $pdo): int {
    $s = $pdo->prepare('SELECT id FROM companies WHERE user_id = ?');
    $s->execute([$_SESSION['user_id']]);
    return (int)$s->fetchColumn();
}

function flash(string $type, string $msg): void {
    $_SESSION['flash'][] = [$type, $msg];
}

// "Under Review" -> "badge s-under-review"  (matches css/style.css)
function status_class(string $status): string {
    return 'badge s-' . strtolower(str_replace(' ', '-', $status));
}

function render_header(string $title = ''): void {
    $b = BASE_URL;
    echo '<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">'
       . '<meta name="viewport" content="width=device-width, initial-scale=1">'
       . '<title>' . e($title) . ' - Internship Portal</title>'
       . '<link rel="stylesheet" href="' . $b . '/css/style.css"></head><body>';
    echo '<header class="topbar"><a class="brand" href="' . $b . '/index.php">Internship Portal</a><nav>';
    if (is_logged_in()) {
        if ($_SESSION['role'] === 'student') {
            echo '<a href="' . $b . '/student/dashboard.php">Dashboard</a>'
               . '<a href="' . $b . '/student/internships.php">Internships</a>'
               . '<a href="' . $b . '/student/applications.php">My applications</a>'
               . '<a href="' . $b . '/student/profile.php">Profile</a>';
        } else {
            echo '<a href="' . $b . '/company/dashboard.php">Dashboard</a>'
               . '<a href="' . $b . '/company/add_internship.php">Add internship</a>'
               . '<a href="' . $b . '/company/internships.php">My internships</a>'
               . '<a href="' . $b . '/company/applicants.php">Applicants</a>';
        }
        echo '<a href="' . $b . '/logout.php">Logout</a>';
    } else {
        echo '<a href="' . $b . '/login.php">Login</a><a href="' . $b . '/register.php">Register</a>';
    }
    echo '</nav></header><main class="container">';
    foreach ($_SESSION['flash'] ?? [] as [$type, $msg]) {
        echo '<div class="alert ' . e($type) . '">' . e($msg) . '</div>';
    }
    unset($_SESSION['flash']);
}

function render_footer(): void {
    echo '</main><footer class="footer">Internship Portal &middot; Web Technology project</footer>'
       . '<script src="' . BASE_URL . '/js/validation.js"></script></body></html>';
}
