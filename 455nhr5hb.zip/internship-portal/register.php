<?php
require_once 'config/database.php';
if (is_logged_in()) redirect(dashboard_path());

$errors = [];
$old = ['name' => '', 'email' => '', 'role' => 'student', 'company_name' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $old['name']         = trim($_POST['name'] ?? '');
    $old['email']        = trim($_POST['email'] ?? '');
    $old['role']         = $_POST['role'] ?? 'student';
    $old['company_name'] = trim($_POST['company_name'] ?? '');
    $password = $_POST['password'] ?? '';
    $confirm  = $_POST['confirm'] ?? '';

    if ($old['name'] === '') $errors[] = 'Name is required.';
    if (!filter_var($old['email'], FILTER_VALIDATE_EMAIL)) $errors[] = 'Enter a valid email.';
    if (!in_array($old['role'], ['student', 'company'])) $errors[] = 'Choose a role.';
    if ($old['role'] === 'company' && $old['company_name'] === '') $errors[] = 'Company name is required.';
    if (strlen($password) < 6) $errors[] = 'Password must be at least 6 characters.';
    if ($password !== $confirm) $errors[] = 'Passwords do not match.';

    if (!$errors) {
        $chk = $pdo->prepare('SELECT id FROM users WHERE email = ?');
        $chk->execute([$old['email']]);
        if ($chk->fetch()) $errors[] = 'This email is already registered.';
    }

    if (!$errors) {
        $pdo->beginTransaction();
        try {
            $pdo->prepare('INSERT INTO users (name, email, password, role) VALUES (?,?,?,?)')
                ->execute([$old['name'], $old['email'], password_hash($password, PASSWORD_DEFAULT), $old['role']]);
            $uid = $pdo->lastInsertId();
            if ($old['role'] === 'student') {
                $pdo->prepare('INSERT INTO students (user_id) VALUES (?)')->execute([$uid]);
            } else {
                $pdo->prepare('INSERT INTO companies (user_id, company_name) VALUES (?,?)')->execute([$uid, $old['company_name']]);
            }
            $pdo->commit();
            flash('success', 'Account created. Please login.');
            redirect('/login.php');
        } catch (Exception $ex) {
            $pdo->rollBack();
            $errors[] = 'Could not create account. Try again.';
        }
    }
}
render_header('Register');
?>
<div class="form-box">
  <h2>Create account</h2>
  <?php foreach ($errors as $er): ?><div class="alert error"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" class="js-validate" novalidate>
    <label>I am a
      <select name="role" id="role">
        <option value="student" <?= $old['role'] === 'student' ? 'selected' : '' ?>>Student</option>
        <option value="company" <?= $old['role'] === 'company' ? 'selected' : '' ?>>Company</option>
      </select>
    </label>
    <label>Full name <input type="text" name="name" value="<?= e($old['name']) ?>" required></label>
    <div id="company-field" style="display:none">
      <label>Company name <input type="text" name="company_name" value="<?= e($old['company_name']) ?>"></label>
    </div>
    <label>Email <input type="email" name="email" value="<?= e($old['email']) ?>" required></label>
    <label>Password <input type="password" name="password" minlength="6" required></label>
    <label>Confirm password <input type="password" name="confirm" required></label>
    <button class="btn" type="submit">Register</button>
  </form>
  <p class="muted">Already registered? <a href="login.php">Login</a></p>
</div>
<?php render_footer(); ?>
