<?php
require_once '../config/database.php';
require_login('company');
$cid = company_id($pdo);

// Update status (only for applications to this company's internships)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $appId  = (int)($_POST['application_id'] ?? 0);
    $status = $_POST['status'] ?? '';
    if (in_array($status, STATUSES)) {
        $pdo->prepare('UPDATE applications a JOIN internships i ON i.id = a.internship_id
                       SET a.status = ? WHERE a.id = ? AND i.company_id = ?')
            ->execute([$status, $appId, $cid]);
        flash('success', 'Status updated to ' . $status . '.');
    }
    redirect('/company/applicants.php' . (!empty($_POST['back']) ? '?internship_id=' . (int)$_POST['back'] : ''));
}

$filter = (int)($_GET['internship_id'] ?? 0);

$mine = $pdo->prepare('SELECT id, title FROM internships WHERE company_id = ? ORDER BY title');
$mine->execute([$cid]);
$myList = $mine->fetchAll();

$sql = 'SELECT a.*, i.title, u.name, u.email, s.phone, s.college, s.department, s.year, s.skills, s.resume
        FROM applications a
        JOIN internships i ON i.id = a.internship_id
        JOIN students s ON s.id = a.student_id
        JOIN users u ON u.id = s.user_id
        WHERE i.company_id = ?';
$params = [$cid];
if ($filter) { $sql .= ' AND i.id = ?'; $params[] = $filter; }
$sql .= ' ORDER BY a.applied_at DESC';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$apps = $stmt->fetchAll();

render_header('Applicants');
?>
<h2>Applicants</h2>
<form method="get" class="search-bar">
  <select name="internship_id" onchange="this.form.submit()">
    <option value="0">All internships</option>
    <?php foreach ($myList as $m): ?>
      <option value="<?= (int)$m['id'] ?>" <?= $filter === (int)$m['id'] ? 'selected' : '' ?>><?= e($m['title']) ?></option>
    <?php endforeach; ?>
  </select>
</form>

<?php if (!$apps): ?><p class="muted">No applicants yet.</p><?php endif; ?>
<?php foreach ($apps as $a): ?>
  <div class="card">
    <div class="row">
      <div>
        <h3><?= e($a['name']) ?></h3>
        <p class="muted">Applied for <strong><?= e($a['title']) ?></strong> on <?= e(date('d M Y', strtotime($a['applied_at']))) ?></p>
      </div>
      <span class="<?= status_class($a['status']) ?>"><?= e($a['status']) ?></span>
    </div>
    <p><?= e($a['email']) ?><?= $a['phone'] ? ' &middot; ' . e($a['phone']) : '' ?></p>
    <p><?= e($a['college']) ?> &middot; <?= e($a['department']) ?> &middot; <?= e($a['year']) ?></p>
    <p><?php foreach (explode(',', (string)$a['skills']) as $sk): if (trim($sk) === '') continue; ?>
      <span class="tag"><?= e(trim($sk)) ?></span><?php endforeach; ?></p>
    <?php if ($a['cover_letter']): ?><p><em><?= nl2br(e($a['cover_letter'])) ?></em></p><?php endif; ?>
    <?php if ($a['resume']): ?>
      <p><a href="<?= BASE_URL ?>/uploads/resumes/<?= e($a['resume']) ?>" target="_blank">View resume</a></p>
    <?php endif; ?>

    <div class="actions">
      <form method="post">
        <input type="hidden" name="application_id" value="<?= (int)$a['id'] ?>">
        <input type="hidden" name="back" value="<?= $filter ?>">
        <button class="btn small" name="status" value="Shortlisted">Shortlist</button>
        <button class="btn small danger" name="status" value="Rejected">Reject</button>
      </form>
      <form method="post">
        <input type="hidden" name="application_id" value="<?= (int)$a['id'] ?>">
        <input type="hidden" name="back" value="<?= $filter ?>">
        <select name="status">
          <?php foreach (STATUSES as $s): ?>
            <option <?= $a['status'] === $s ? 'selected' : '' ?>><?= e($s) ?></option>
          <?php endforeach; ?>
        </select>
        <button class="btn small ghost" type="submit">Update</button>
      </form>
    </div>
  </div>
<?php endforeach; ?>
<?php render_footer(); ?>
