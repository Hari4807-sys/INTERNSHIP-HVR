<?php
require_once '../config/database.php';
require_login('student');
$sid = student_id($pdo);
$id  = (int)($_GET['id'] ?? $_POST['id'] ?? 0);

$stmt = $pdo->prepare('SELECT i.*, c.company_name FROM internships i JOIN companies c ON c.id = i.company_id
                       WHERE i.id = ? AND i.deadline >= CURDATE()');
$stmt->execute([$id]);
$job = $stmt->fetch();
if (!$job) { flash('error', 'Internship not found or deadline passed.'); redirect('/student/internships.php'); }

$dup = $pdo->prepare('SELECT id FROM applications WHERE internship_id = ? AND student_id = ?');
$dup->execute([$id, $sid]);
if ($dup->fetch()) { flash('info', 'You already applied to this internship.'); redirect('/student/applications.php'); }

$prof = $pdo->prepare('SELECT college, skills, resume FROM students WHERE id = ?');
$prof->execute([$sid]);
$p = $prof->fetch();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$p['resume']) {
        flash('error', 'Upload your resume in your profile before applying.');
        redirect('/student/profile.php');
    }
    $cover = trim($_POST['cover_letter'] ?? '');
    $pdo->prepare('INSERT INTO applications (internship_id, student_id, cover_letter) VALUES (?,?,?)')
        ->execute([$id, $sid, $cover]);
    flash('success', 'Application submitted.');
    redirect('/student/applications.php');
}
render_header('Apply');
?>
<div class="form-box wide">
  <h2>Apply: <?= e($job['title']) ?></h2>
  <p class="muted"><?= e($job['company_name']) ?> &middot; <?= e($job['location']) ?> &middot; <?= e($job['duration']) ?></p>
  <p><?= nl2br(e($job['description'])) ?></p>
  <?php if (!$p['resume']): ?>
    <div class="alert info">You need a resume on your profile. <a href="profile.php">Upload it here</a>.</div>
  <?php endif; ?>
  <form method="post">
    <input type="hidden" name="id" value="<?= $id ?>">
    <label>Cover letter (optional)
      <textarea name="cover_letter" rows="5" placeholder="Why are you a good fit?"></textarea>
    </label>
    <button class="btn" type="submit">Submit application</button>
    <a class="btn ghost" href="internships.php">Cancel</a>
  </form>
</div>
<?php render_footer(); ?>
