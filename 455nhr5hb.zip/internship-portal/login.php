<?php
require_once 'config/database.php';
if (is_logged_in()) redirect(dashboard_path());

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = $_POST['password'] ?? '';

    $stmt = $pdo->prepare('SELECT * FROM users WHERE email = ?');
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if ($user && password_verify($password, $user['password'])) {
        session_regenerate_id(true);
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role']    = $user['role'];
        $_SESSION['name']    = $user['name'];
        redirect(dashboard_path());
    }
    $error = 'Wrong email or password.';
}
render_header('Login');
?>
<div class="form-box">
  <h2>Login</h2>
  <?php if ($error): ?><div class="alert error"><?= e($error) ?></div><?php endif; ?>
  <form method="post" class="js-validate" novalidate>
    <label>Email <input type="email" name="email" required></label>
    <label>Password <input type="password" name="password" required></label>
    <button class="btn" type="submit">Login</button>
  </form>
  <p class="muted"><a href="forgot_password.php">Forgot password?</a> &middot; <a href="register.php">Create account</a></p>
</div>
<?php render_footer(); ?>
