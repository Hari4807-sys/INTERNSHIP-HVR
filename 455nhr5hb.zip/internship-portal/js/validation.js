// Client-side validation for forms with class "js-validate"
document.addEventListener('DOMContentLoaded', function () {

  // Show company name field only for company role (register page)
  var role = document.getElementById('role');
  var companyField = document.getElementById('company-field');
  if (role && companyField) {
    var toggle = function () {
      var isCompany = role.value === 'company';
      companyField.style.display = isCompany ? 'block' : 'none';
      var input = companyField.querySelector('input');
      if (input) input.required = isCompany;
    };
    role.addEventListener('change', toggle);
    toggle();
  }

  function setError(field, message) {
    clearError(field);
    field.classList.add('invalid');
    var span = document.createElement('span');
    span.className = 'field-error';
    span.textContent = message;
    field.parentNode.appendChild(span);
  }

  function clearError(field) {
    field.classList.remove('invalid');
    var old = field.parentNode.querySelector('.field-error');
    if (old) old.remove();
  }

  document.querySelectorAll('form.js-validate').forEach(function (form) {
    form.addEventListener('submit', function (ev) {
      var ok = true;

      form.querySelectorAll('input, select, textarea').forEach(function (f) {
        if (f.type === 'hidden' || f.type === 'file' || f.offsetParent === null) return;
        clearError(f);
        var v = f.value.trim();

        if (f.required && v === '') {
          setError(f, 'This field is required.'); ok = false; return;
        }
        if (f.type === 'email' && v !== '' && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) {
          setError(f, 'Enter a valid email address.'); ok = false; return;
        }
        if (f.name === 'password' && f.getAttribute('minlength') && v.length < 6) {
          setError(f, 'Password must be at least 6 characters.'); ok = false; return;
        }
        if (f.name === 'phone' && v !== '' && !/^[0-9+\-\s]{8,15}$/.test(v)) {
          setError(f, 'Enter a valid phone number.'); ok = false; return;
        }
      });

      var pw = form.querySelector('input[name="password"]');
      var cf = form.querySelector('input[name="confirm"]');
      if (pw && cf && pw.value !== cf.value) {
        setError(cf, 'Passwords do not match.'); ok = false;
      }

      if (!ok) ev.preventDefault();
    });
  });
});
