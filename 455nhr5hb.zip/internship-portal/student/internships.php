<?php
require_once '../config/database.php';
require_login('student');
$sid = student_id($pdo);

$q   = trim($_GET['q'] ?? '');
$loc = trim($_GET['location'] ?? '');

$sql = "SELECT i.*, c.company_name,
          (SELECT COUNT(*) FROM applications a WHERE a.internship_id = i.id AND a.student_id = ?) AS applied
        FROM internships i
        JOIN companies c ON c.id = i.company_id
        WHERE i.deadline >= CURDATE()
          AND (i.title LIKE ? OR i.skills_required LIKE ? OR c.company_name LIKE ?)
          AND i.location LIKE ?
        ORDER BY i.created_at DESC";
$stmt = $pdo->prepare($sql);
$like = "%$q%";
$stmt->execute([$sid, $like, $like, $like, "%$loc%"]);
$list = $stmt->fetchAll();

render_header('Internships');
?>
<h2>Search internships</h2>
<form method="get" class="search-bar">
  <input type="text" name="q" value="<?= e($q) ?>" placeholder="Title, skill or company">
  <input type="text" name="location" value="<?= e($loc) ?>" placeholder="Location">
  <button class="btn" type="submit">Search</button>
</form>

<?php if (!$list): ?>
  <p class="muted">No internships match your search.</p>
<?php endif; ?>
<?php foreach ($list as $i): ?>
  <div class="card row">
    <div>
      <h3><?= e($i['title']) ?></h3>
      <p class="muted"><?= e($i['company_name']) ?> &middot; <?= e($i['location']) ?> &middot; <?= e($i['duration']) ?></p>
      <p><?= e(mb_strimwidth($i['description'], 0, 160, '...')) ?></p>
      <p>
        <?php foreach (explode(',', (string)$i['skills_required']) as $sk): if (trim($sk) === '') continue; ?>
          <span class="tag"><?= e(trim($sk)) ?></span>
        <?php endforeach; ?>
      </p>
      <p class="muted">Stipend: <?= e($i['stipend'] ?: 'Not disclosed') ?> &middot; Apply by <?= e($i['deadline']) ?></p>
    </div>
    <div>
      <?php if ($i['applied']): ?>
        <span class="badge s-applied">Applied</span>
      <?php else: ?>
        <a class="btn" href="apply.php?id=<?= (int)$i['id'] ?>">Apply</a>
      <?php endif; ?>
    </div>
  </div>
<?php endforeach; ?>
<?php render_footer(); ?>
