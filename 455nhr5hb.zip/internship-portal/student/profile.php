<?php
require_once '../config/database.php';
require_login('student');
$sid = student_id($pdo);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $phone      = trim($_POST['phone'] ?? '');
    $college    = trim($_POST['college'] ?? '');
    $department = trim($_POST['department'] ?? '');
    $year       = trim($_POST['year'] ?? '');
    // Skills: comma separated, cleaned
    $skillList  = array_filter(array_map('trim', explode(',', $_POST['skills'] ?? '')));
    $skills     = implode(', ', array_unique($skillList));

    if ($phone !== '' && !preg_match('/^[0-9+\-\s]{8,15}$/', $phone)) $errors[] = 'Enter a valid phone number.';

    $resume = null;
    if (!empty($_FILES['resume']['name'])) {
        $ext = strtolower(pathinfo($_FILES['resume']['name'], PATHINFO_EXTENSION));
        if ($_FILES['resume']['error'] !== UPLOAD_ERR_OK) {
            $errors[] = 'Resume upload failed.';
        } elseif (!in_array($ext, ['pdf', 'doc', 'docx'])) {
            $errors[] = 'Resume must be PDF, DOC or DOCX.';
        } elseif ($_FILES['resume']['size'] > 2 * 1024 * 1024) {
            $errors[] = 'Resume must be under 2 MB.';
        } else {
            $dir = __DIR__ . '/../uploads/resumes/';
            if (!is_dir($dir)) mkdir($dir, 0755, true);
            $resume = 'resume_' . $sid . '_' . time() . '.' . $ext;
            if (!move_uploaded_file($_FILES['resume']['tmp_name'], $dir . $resume)) {
                $errors[] = 'Could not save the resume file.';
                $resume = null;
            }
        }
    }

    if (!$errors) {
        if ($resume) {
            $pdo->prepare('UPDATE students SET phone=?, college=?, department=?, year=?, skills=?, resume=? WHERE id=?')
                ->execute([$phone, $college, $department, $year, $skills, $resume, $sid]);
        } else {
            $pdo->prepare('UPDATE students SET phone=?, college=?, department=?, year=?, skills=? WHERE id=?')
                ->execute([$phone, $college, $department, $year, $skills, $sid]);
        }
        flash('success', 'Profile saved.');
        redirect('/student/profile.php');
    }
}

$s = $pdo->prepare('SELECT s.*, u.name, u.email FROM students s JOIN users u ON u.id = s.user_id WHERE s.id = ?');
$s->execute([$sid]);
$st = $s->fetch();

render_header('Profile');
?>
<div class="form-box wide">
  <h2>My profile</h2>
  <p class="muted"><?= e($st['name']) ?> &middot; <?= e($st['email']) ?></p>
  <?php foreach ($errors as $er): ?><div class="alert error"><?= e($er) ?></div><?php endforeach; ?>
  <form method="post" enctype="multipart/form-data" class="js-validate" novalidate>
    <label>Phone <input type="text" name="phone" value="<?= e($st['phone']) ?>"></label>
    <label>College <input type="text" name="college" value="<?= e($st['college']) ?>" required></label>
    <label>Department <input type="text" name="department" value="<?= e($st['department']) ?>"></label>
    <label>Year
      <select name="year">
        <?php foreach (['', '1st year', '2nd year', '3rd year', '4th year'] as $y): ?>
          <option value="<?= e($y) ?>" <?= $st['year'] === $y ? 'selected' : '' ?>><?= $y ?: 'Select year' ?></option>
        <?php endforeach; ?>
      </select>
    </label>
    <label>Skills (separate with commas)
      <input type="text" name="skills" value="<?= e($st['skills']) ?>" placeholder="PHP, MySQL, HTML, CSS">
    </label>
    <?php if ($st['skills']): ?>
      <p><?php foreach (explode(',', $st['skills']) as $sk): ?><span class="tag"><?= e(trim($sk)) ?></span><?php endforeach; ?></p>
    <?php endif; ?>
    <label>Resume (PDF/DOC/DOCX, max 2 MB) <input type="file" name="resume" accept=".pdf,.doc,.docx"></label>
    <?php if ($st['resume']): ?>
      <p>Current resume: <a href="<?= BASE_URL ?>/uploads/resumes/<?= e($st['resume']) ?>" target="_blank">View</a></p>
    <?php endif; ?>
    <button class="btn" type="submit">Save profile</button>
  </form>
</div>
<?php render_footer(); ?>
