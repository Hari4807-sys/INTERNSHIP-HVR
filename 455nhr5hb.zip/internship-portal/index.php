<?php
require_once 'config/database.php';
if (is_logged_in()) redirect(dashboard_path());

$latest = $pdo->query("SELECT i.*, c.company_name FROM internships i JOIN companies c ON c.id = i.company_id
                       WHERE i.deadline >= CURDATE() ORDER BY i.created_at DESC LIMIT 6")->fetchAll();
render_header('Home');
?>
<section class="hero">
  <h1>Find your first internship.</h1>
  <p>Students build a profile and apply. Companies post openings and shortlist applicants.</p>
  <a class="btn" href="register.php">Create an account</a>
  <a class="btn ghost" href="login.php">Login</a>
</section>

<h2>Latest openings</h2>
<?php if (!$latest): ?>
  <p class="muted">No internships posted yet.</p>
<?php else: ?>
<div class="grid">
  <?php foreach ($latest as $i): ?>
    <div class="card">
      <h3><?= e($i['title']) ?></h3>
      <p class="muted"><?= e($i['company_name']) ?> &middot; <?= e($i['location']) ?></p>
      <p>Stipend: <?= e($i['stipend'] ?: 'Not disclosed') ?> &middot; <?= e($i['duration']) ?></p>
      <p class="muted">Apply by <?= e($i['deadline']) ?></p>
    </div>
  <?php endforeach; ?>
</div>
<?php endif; ?>
<?php render_footer(); ?>
