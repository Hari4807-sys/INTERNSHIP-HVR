<?php
require_once '../config/database.php';
require_login('company');
$cid = company_id($pdo);

// Delete (only own internships)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    $pdo->prepare('DELETE FROM internships WHERE id = ? AND company_id = ?')->execute([(int)$_POST['delete_id'], $cid]);
    flash('success', 'Internship deleted.');
    redirect('/company/internships.php');
}

$stmt = $pdo->prepare('SELECT i.*, (SELECT COUNT(*) FROM applications a WHERE a.internship_id = i.id) AS applicants
                       FROM internships i WHERE i.company_id = ? ORDER BY i.created_at DESC');
$stmt->execute([$cid]);
$list = $stmt->fetchAll();

render_header('My Internships');
?>
<h2>My internships</h2>
<?php if (!$list): ?>
  <p class="muted">Nothing posted yet. <a href="add_internship.php">Add your first internship</a>.</p>
<?php else: ?>
<div class="table-wrap">
<table>
  <tr><th>Title</th><th>Location</th><th>Deadline</th><th>Applicants</th><th></th></tr>
  <?php foreach ($list as $i): ?>
  <tr>
    <td><?= e($i['title']) ?></td>
    <td><?= e($i['location']) ?></td>
    <td><?= e($i['deadline']) ?><?= strtotime($i['deadline']) < strtotime('today') ? ' <span class="muted">(closed)</span>' : '' ?></td>
    <td><a href="applicants.php?internship_id=<?= (int)$i['id'] ?>"><?= (int)$i['applicants'] ?></a></td>
    <td>
      <form method="post" onsubmit="return confirm('Delete this internship and its applications?')">
        <input type="hidden" name="delete_id" value="<?= (int)$i['id'] ?>">
        <button class="btn small danger" type="submit">Delete</button>
      </form>
    </td>
  </tr>
  <?php endforeach; ?>
</table>
</div>
<?php endif; ?>
<?php render_footer(); ?>
